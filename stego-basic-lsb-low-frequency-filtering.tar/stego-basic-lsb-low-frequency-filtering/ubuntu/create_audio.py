import numpy as np
import wave
import struct

# Tham số âm thanh
sample_rate = 44100  # Tần số mẫu (Hz)
duration = 5  # Thời gian (giây)
frequency = 440.0  # Tần số âm (Hz), ở đây là A4 (440 Hz)

# Tạo một sóng sin
t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
audio_signal = np.sin(2 * np.pi * frequency * t)

# Chuẩn bị dữ liệu để ghi vào file
max_amplitude = 32767  # Độ lớn tối đa của mẫu âm thanh 16-bit PCM
audio_signal_int16 = np.int16(audio_signal * max_amplitude)

# Tạo tệp WAV
output_filename = "input_audio.wav"
with wave.open(output_filename, 'w') as wf:
    # Thiết lập các tham số WAV
    wf.setnchannels(1)  # 1 kênh (mono)
    wf.setsampwidth(2)  # 2 bytes mỗi mẫu (16-bit)
    wf.setframerate(sample_rate)

    # Ghi dữ liệu vào file WAV
    for sample in audio_signal_int16:
        wf.writeframes(struct.pack('h', sample))

print(f"File âm thanh WAV đã được tạo tại {output_filename}")

