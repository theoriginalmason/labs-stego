import numpy as np
import wave
import scipy.signal as signal
import matplotlib.pyplot as plt

# Hàm để đọc file âm thanh WAV
def read_audio(file_path):
    with wave.open(file_path, 'rb') as audio_file:
        params = audio_file.getparams()
        num_frames = params[3]
        audio_data = np.frombuffer(audio_file.readframes(num_frames), dtype=np.int16)
    return audio_data, params

# Hàm để lưu file âm thanh sau khi xử lý
def write_audio(file_path, audio_data, params):
    with wave.open(file_path, 'wb') as audio_file:
        audio_file.setparams(params)
        audio_file.writeframes(audio_data.tobytes())

# Hàm lọc tần số thấp
def low_pass_filter(audio_data, cutoff_freq, sample_rate):
    nyquist = 0.5 * sample_rate
    normal_cutoff = cutoff_freq / nyquist
    b, a = signal.butter(4, normal_cutoff, btype='low')
    filtered_audio = signal.filtfilt(b, a, audio_data)
    return filtered_audio.astype(np.int16)

# Đọc tệp âm thanh
audio_data, params = read_audio('input_audio.wav')

# Lọc tần số thấp
filtered_audio = low_pass_filter(audio_data, cutoff_freq=5000, sample_rate=params[2])

# Định nghĩa tên tệp đầu ra
output_file_path = 'filtered_audio.wav'

# Lưu tệp âm thanh đã lọc
write_audio(output_file_path, filtered_audio, params)

# In thông báo tệp âm thanh được lưu tại đâu
print(f"Tệp âm thanh đã được lưu tại: {output_file_path}")

