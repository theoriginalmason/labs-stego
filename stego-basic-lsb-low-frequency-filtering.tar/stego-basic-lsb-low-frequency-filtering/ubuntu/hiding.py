import numpy as np
from preprocessing import filtered_audio, write_audio, params

# Hàm để chuyển đổi văn bản thành chuỗi nhị phân
def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

# Hàm giấu thông tin vào âm thanh
def embed_message(audio_data, message):
    message_bin = text_to_binary(message)
    message_len = len(message_bin)
    audio_data = audio_data.astype(np.int32)  # Dùng int32 để có đủ không gian lưu trữ
    for i in range(message_len):
        # Chèn thông tin vào các bit thấp của mỗi mẫu âm thanh
        audio_data[i] = (audio_data[i] & ~1) | int(message_bin[i])
    return audio_data.astype(np.int16)

# Đọc thông tin từ tệp message.txt
with open('input.txt', 'r') as message_file:
    message = message_file.read()

# Giấu thông tin vào âm thanh
audio_data_with_message = embed_message(filtered_audio, message)

# Lưu âm thanh đã giấu thông tin
output_file_path = 'audio_with_message.wav'
write_audio(output_file_path, audio_data_with_message, params)

# In thông báo tệp âm thanh đã giấu thông tin
print(f"Tệp âm thanh đã được giấu thông tin và lưu tại: {output_file_path}")

