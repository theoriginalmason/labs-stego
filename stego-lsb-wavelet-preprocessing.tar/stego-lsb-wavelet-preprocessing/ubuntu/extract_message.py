import numpy as np
import librosa
from scipy.io.wavfile import read


# Đọc file âm thanh (thường là wav)
def load_audio(file_path):
    y, sr = librosa.load(file_path, sr=None)  # sr=None để giữ nguyên sample rate của file
    return y, sr


# Giải mã thông điệp từ âm thanh giấu thông qua LSB
def extract_message_from_audio(signal, message_length,frequency_txt):
    # Lấy bit thấp nhất của mỗi phần tử tín hiệu âm thanh
    signal_bin = [format(int(x), '016b') for x in signal]  # Chuyển tín hiệu thành dạng nhị phân 16 bit
    message_bin = ''.join([s[-1] for s in signal_bin[:message_length]])  # Lấy bit cuối cùng từ mỗi phần tử

    # Chia chuỗi nhị phân thành các ký tự (8 bit mỗi ký tự)
    message = ''.join(chr(int(message_bin[i:i + 8], 2)) for i in range(0, len(message_bin), 8))
    frequency_txt = 'message.txt'
    with open(frequency_txt, 'r') as file:
        decoded_message = file.read()  # Đọc toàn bộ nội dung trong file
        print("extracted message: " + decoded_message)  # In ra nội dung của file


# Main
def main():
    # Đường dẫn tới file âm thanh đã giấu thông điệp
    input_audio_path = 'output_audio_with_message.wav'

    # Tải âm thanh
    signal, sr = load_audio(input_audio_path)

    # Đọc độ dài thông điệp (số bit được giấu trong âm thanh)
    message_length = len(signal)  # Bạn có thể điều chỉnh này tùy theo thông điệp đã giấu

    # Giải mã thông điệp
    decoded_message = extract_message_from_audio(signal, message_length, 'output_audi_with_message.wav')




if __name__ == "__main__":
    main()

