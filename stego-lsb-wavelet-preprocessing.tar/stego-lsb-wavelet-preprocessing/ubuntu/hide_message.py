import numpy as np
import librosa
import pywt
from scipy.io.wavfile import write
import os


# Đọc file âm thanh (thường là wav)
def load_audio(file_path):
    y, sr = librosa.load(file_path, sr=None)  # sr=None để giữ nguyên sample rate của file
    return y, sr


# Biến đổi sóng wavelet
def wavelet_transform(signal, wavelet='haar', level=5):
    coeffs = pywt.wavedec(signal, wavelet, level=level)
    return coeffs


# Giấu thông điệp trong âm thanh sử dụng kỹ thuật LSB
def hide_message_in_audio(signal, message_file='message.txt'):
    # Đọc thông điệp từ file
    with open(message_file, 'r') as file:
        message = file.read()

    # Chuyển thông điệp thành các mã nhị phân
    message_bin = ''.join(format(ord(c), '08b') for c in message)

    # Kiểm tra nếu thông điệp quá dài
    if len(message_bin) > len(signal):
        raise ValueError("Message is too long to hide in the audio signal.")

    # Giấu thông điệp vào tín hiệu âm thanh
    signal_bin = [format(int(x), '016b') for x in signal]  # Chuyển đổi tín hiệu sang dạng chuỗi nhị phân 16 bit
    for i in range(len(message_bin)):
        signal_bin[i] = signal_bin[i][:-1] + message_bin[i]  # Thay đổi bit cuối cùng của mỗi phần tử

    # Chuyển đổi lại từ nhị phân thành kiểu int16
    hidden_signal = np.array([int(b, 2) for b in signal_bin], dtype=np.int16)

    return hidden_signal, message


# Lưu âm thanh đã giấu thông điệp vào file WAV
def save_audio(file_path, signal, sample_rate):
    write(file_path, sample_rate, signal)


# In ra các hệ số wavelet
def print_wavelet_coeffs(coeffs):
    for i, coeff in enumerate(coeffs):
        print(f"Level {i} Coefficients: \n{coeff}\n")


# Main
def main():
    # Đường dẫn tới file âm thanh
    input_audio_path = 'input_audio.wav'
    output_audio_path = 'output_audio_with_message.wav'

    # Tải âm thanh
    signal, sr = load_audio(input_audio_path)

    # Biến đổi sóng wavelet
    coeffs = wavelet_transform(signal, wavelet='haar', level=5)

    # In ra các hệ số wavelet của tín hiệu gốc
    print("Wavelet Coefficients (Before Hiding Message):")
    print_wavelet_coeffs(coeffs)

    # Giấu thông điệp vào âm thanh
    hidden_signal, message = hide_message_in_audio(signal)

    # Lưu âm thanh đã giấu thông điệp
    save_audio(output_audio_path, hidden_signal, sr)
    print(f"Audio with hidden message has been saved to: {output_audio_path}")

    # In thông điệp đã giấu
    print(f"Hidden Message: {message}")

    # Biến đổi sóng wavelet của âm thanh đã giấu thông điệp
    coeffs_hidden = wavelet_transform(hidden_signal, wavelet='haar', level=5)

    # In ra các hệ số wavelet của tín hiệu đã giấu thông điệp
    print("Wavelet Coefficients (After Hiding Message):")
    print_wavelet_coeffs(coeffs_hidden)


if __name__ == "__main__":
    main()

