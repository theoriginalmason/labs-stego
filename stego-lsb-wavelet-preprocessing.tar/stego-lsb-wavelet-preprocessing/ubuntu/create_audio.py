import numpy as np
from scipy.io.wavfile import write


# Tạo tín hiệu sóng sine (sine wave) làm âm thanh đầu vào
def create_audio(file_path, sample_rate=44100, duration=5, frequency=440):
    # Tham số:
    # sample_rate: Tần số mẫu (44.1 kHz cho chất lượng âm thanh tốt)
    # duration: Thời gian âm thanh (5 giây)
    # frequency: Tần số của sóng sine (440 Hz = A4 - nốt nhạc la)

    # Tạo mảng thời gian
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)

    # Tạo tín hiệu sóng sine
    audio_signal = 32767 * np.sin(2 * np.pi * frequency * t)  # 32767 để tạo tín hiệu 16-bit PCM

    # Chuyển đổi tín hiệu thành kiểu dữ liệu int16
    audio_signal = audio_signal.astype(np.int16)

    # Lưu tín hiệu vào file WAV
    write(file_path, sample_rate, audio_signal)


# Main
def main():
    # Đường dẫn tới file âm thanh
    file_path = 'input_audio.wav'

    # Tạo âm thanh và lưu vào file
    create_audio(file_path)

    print(f"Đã tạo file âm thanh đầu vào: {file_path}")


if __name__ == "__main__":
    main()

