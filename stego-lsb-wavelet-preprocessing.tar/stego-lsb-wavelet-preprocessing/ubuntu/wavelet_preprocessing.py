import numpy as np
import librosa
import pywt
import matplotlib.pyplot as plt


# Đọc file âm thanh (thường là wav)
def load_audio(file_path):
    y, sr = librosa.load(file_path, sr=None)  # sr=None để giữ nguyên sample rate của file
    return y, sr


# Biến đổi sóng wavelet
def wavelet_transform(signal, wavelet='haar', level=5):
    # Thực hiện biến đổi wavelet 1D
    coeffs = pywt.wavedec(signal, wavelet, level=level)
    return coeffs


# In ra các hệ số wavelet cho từng cấp độ
def print_wavelet_coeffs(coeffs):
    for i, coeff in enumerate(coeffs):
        print(f"Level {i} Coefficients: \n{coeff}\n")


# Hiển thị kết quả biến đổi sóng wavelet
def plot_wavelet_transform(coeffs, level=5):
    fig, axes = plt.subplots(level + 1, 1, figsize=(10, 8))
    for i in range(level + 1):
        axes[i].plot(coeffs[i])
        axes[i].set_title(f'Level {i} Coefficients')
    plt.tight_layout()
    plt.show()


# Main
def main():
    # Đường dẫn tới file âm thanh
    file_path = 'input_audio.wav'

    # Tải âm thanh
    signal, sr = load_audio(file_path)

    # Hiển thị sóng âm gốc
    plt.figure(figsize=(10, 4))
    plt.plot(signal)
    plt.title("Original Audio Signal")
    plt.xlabel("Sample")
    plt.ylabel("Amplitude")
    plt.show()

    # Biến đổi sóng wavelet
    coeffs = wavelet_transform(signal, wavelet='haar', level=5)

    # In ra các hệ số wavelet
    print_wavelet_coeffs(coeffs)

    # Hiển thị các hệ số wavelet
    plot_wavelet_transform(coeffs, level=5)


if __name__ == "__main__":
    main()

