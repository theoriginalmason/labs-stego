# extract_message.py
import numpy as np
import scipy.io.wavfile as wav

# Hàm trích xuất thông điệp từ âm thanh
def extract_message_from_audio(audio_file, message_length, output_message_file):
    # Đọc âm thanh đã giấu thông điệp
    fs, audio_with_message = wav.read(audio_file)

    # Trích xuất thông điệp từ 8 bit cuối cùng của mỗi mẫu âm thanh
    extracted_bin = ''.join(str(audio_with_message[i] & 1) for i in range(message_length))
    extracted_message = ''.join(chr(int(extracted_bin[i:i+8], 2)) for i in range(0, len(extracted_bin), 8))

    # Lưu thông điệp đã giải mã ra file
    with open(output_message_file, 'w') as file:
        file.write(extracted_message)
    print(f"Thông điệp đã được giải mã và lưu vào file '{output_message_file}'.")

# Thực thi
message_length = 8 * len(open('input.txt').read())  # Tính chiều dài thông điệp đã giấu
extract_message_from_audio('audio_with_message.wav', message_length, 'extracted_message.txt')

