# create_input_audio.py
import numpy as np
import scipy.io.wavfile as wav

# Các tham số cho âm thanh đầu vào
fs = 44100  # Tần số lấy mẫu (samples per second)
duration = 5  # Thời gian âm thanh (giây)
frequency = 440  # Tần số âm thanh (Hz), A4 note (440Hz)

# Tạo sóng sin (tạo âm thanh)
t = np.linspace(0, duration, int(fs * duration), endpoint=False)  # Tạo mảng thời gian
audio_data = np.sin(2 * np.pi * frequency * t)  # Tạo sóng sin

# Chuyển đổi dữ liệu âm thanh về kiểu int16 (cho phép lưu trữ dưới dạng WAV)
audio_data = np.int16(audio_data * 32767)  # Chuẩn hóa vào dải giá trị int16

# Lưu âm thanh vào file WAV
wav.write('input_audio.wav', fs, audio_data)

# In ra thông báo
print("File âm thanh 'input_audio.wav' đã được tạo thành công.")

