# embed_message.py
import numpy as np
import scipy.io.wavfile as wav

# Hàm giấu thông điệp vào âm thanh
def hide_message_in_audio(audio_file, message_file, output_audio_file):
    # Đọc thông điệp cần giấu từ file
    with open(message_file, 'r') as file:
        message = file.read()

    # Chuyển thông điệp thành dạng nhị phân
    message_bin = ''.join(format(ord(i), '08b') for i in message)

    # Đọc âm thanh đã lọc
    fs, data = wav.read(audio_file)
    data = np.array(data, dtype=np.int16)
    message_len = len(message_bin)

    # Giấu thông điệp vào 8 bit cuối cùng của mỗi mẫu âm thanh
    for i in range(message_len):
        data[i] = (data[i] & ~1) | int(message_bin[i])

    # Lưu âm thanh đã giấu thông điệp
    wav.write(output_audio_file, fs, data)
    print(f"Âm thanh đã giấu thông điệp và lưu vào file '{output_audio_file}'.")

# Thực thi
hide_message_in_audio('filtered_audio.wav', 'input.txt', 'audio_with_message.wav')

