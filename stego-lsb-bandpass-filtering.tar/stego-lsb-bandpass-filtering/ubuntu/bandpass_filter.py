# bandpass_filter.py
import numpy as np
import scipy.io.wavfile as wav
from scipy.signal import butter, lfilter

# Hàm tạo bộ lọc bandpass
def butter_bandpass(lowcut, highcut, fs, order=5):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    return b, a

# Hàm áp dụng bộ lọc bandpass
def bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order)
    y = lfilter(b, a, data)
    return y

# Đọc file âm thanh đầu vào
fs, data = wav.read('input_audio.wav')

# Lọc âm thanh với dải bandpass
lowcut = 300.0
highcut = 3000.0
filtered_data = bandpass_filter(data, lowcut, highcut, fs)

# Lưu âm thanh đã lọc
wav.write('filtered_audio.wav', fs, np.array(filtered_data, dtype=np.int16))

# In ra thông báo
print("Âm thanh đã được lọc và lưu vào file 'filtered_audio.wav'.")

