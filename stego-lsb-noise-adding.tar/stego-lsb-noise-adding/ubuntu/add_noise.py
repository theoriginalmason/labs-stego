import numpy as np
import wave
import struct
import random


def add_noise(input_audio_path, output_audio_path, noise_level=0.1):
    # Mở file âm thanh đầu vào
    with wave.open(input_audio_path, 'rb') as infile:
        params = infile.getparams()
        frames = infile.readframes(params.nframes)
        audio_data = np.array(struct.unpack(f'{params.nframes}h', frames))

        # Thêm tạp âm ngẫu nhiên vào tín hiệu âm thanh
        noise = np.random.randn(len(audio_data)) * noise_level
        audio_data_with_noise = audio_data + noise.astype(np.int16)

        # Giới hạn lại giá trị âm thanh không vượt quá biên độ
        audio_data_with_noise = np.clip(audio_data_with_noise, -32768, 32767)

        # Lưu âm thanh có tạp âm vào file đầu ra
        with wave.open(output_audio_path, 'wb') as outfile:
            outfile.setparams(params)
            frames_with_noise = struct.pack(f'{len(audio_data_with_noise)}h', *audio_data_with_noise)
            outfile.writeframes(frames_with_noise)

    # In ra kết quả
    print(f"Tạp âm đã được thêm vào âm thanh. File đầu ra: {output_audio_path}")


# Sử dụng hàm
add_noise('input_audio.wav', 'output_with_noise.wav', noise_level=0.1)

