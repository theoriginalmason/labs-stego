import wave
import struct

import numpy as np


def bin_to_message(binary_message):
    """Chuyển chuỗi nhị phân thành thông điệp"""
    message = ''
    for i in range(0, len(binary_message), 8):
        byte = binary_message[i:i + 8]
        message += chr(int(byte, 2))
    return message


def decode_message(input_audio_path):
    # Mở file âm thanh đầu vào
    with wave.open(input_audio_path, 'rb') as infile:
        params = infile.getparams()
        frames = infile.readframes(params.nframes)
        audio_data = np.array(struct.unpack(f'{params.nframes}h', frames))

        # Lấy chuỗi nhị phân từ LSB
        binary_message = ''
        for sample in audio_data:
            binary_message += str(sample & 1)

        # Tìm chuỗi kết thúc '1111111111111110'
        end_marker = '1111111111111110'
        end_index = binary_message.find(end_marker)
        if end_index != -1:
            binary_message = binary_message[:end_index]

        # Chuyển chuỗi nhị phân thành thông điệp
        message = bin_to_message(binary_message)
        return message


# Sử dụng hàm
decoded_message = decode_message('audio_with_message.wav')
print(f"Thông điệp đã giải mã: {decoded_message}")

