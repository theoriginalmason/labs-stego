import numpy as np
import wave
import struct

# Tham số cho âm thanh (tần số, thời gian, độ phân giải, v.v.)
framerate = 44100  # Tần số mẫu (samples per second)
duration = 5  # Thời gian âm thanh (giây)
frequency = 440  # Tần số của sóng (Hz) - Tần số 440 Hz tương ứng với nốt La (A4)

# Tạo mảng thời gian cho âm thanh
t = np.linspace(0, duration, int(framerate * duration), endpoint=False)

# Tạo sóng hình sin với tần số 440Hz
audio_data = np.sin(2 * np.pi * frequency * t)

# Chuyển đổi sóng hình sin thành dữ liệu âm thanh (16-bit PCM)
audio_data = np.int16(audio_data * 32767)  # Chuyển đổi sang giá trị 16-bit PCM

# Lưu âm thanh vào file WAV
def save_wav(filename, data, framerate):
    with wave.open(filename, 'wb') as wav_file:
        wav_file.setnchannels(1)  # Mono (1 kênh)
        wav_file.setsampwidth(2)  # 2 byte mỗi mẫu (16-bit)
        wav_file.setframerate(framerate)
        wav_file.writeframes(data.tobytes())

# Lưu âm thanh vào file input_audio.wav
output_audio_file = "input_audio.wav"
save_wav(output_audio_file, audio_data, framerate)

print(f"Audio file {output_audio_file} has been created.")

