import wave
import struct

import numpy as np


def message_to_bin(message):
    """Chuyển thông điệp thành chuỗi nhị phân"""
    binary_message = ''.join(format(ord(c), '08b') for c in message)
    return binary_message


def embed_message(input_audio_path, message_path, output_audio_path):
    # Đọc thông điệp từ file
    with open(message_path, 'r') as msg_file:
        message = msg_file.read()

    # Chuyển thông điệp thành chuỗi nhị phân
    binary_message = message_to_bin(message) + '1111111111111110'  # Thêm dấu chấm kết thúc

    # Mở file âm thanh đầu vào
    with wave.open(input_audio_path, 'rb') as infile:
        params = infile.getparams()
        frames = infile.readframes(params.nframes)
        audio_data = np.array(struct.unpack(f'{params.nframes}h', frames))

        # Đảm bảo đủ không gian để giấu thông điệp
        if len(binary_message) > len(audio_data):
            raise ValueError("Thông điệp quá dài để giấu vào âm thanh này")

        # Giấu thông điệp vào LSB của tín hiệu âm thanh
        for i in range(len(binary_message)):
            audio_data[i] = (audio_data[i] & ~1) | int(binary_message[i])

        # Lưu âm thanh đã giấu tin vào file đầu ra
        with wave.open(output_audio_path, 'wb') as outfile:
            outfile.setparams(params)
            frames_with_message = struct.pack(f'{len(audio_data)}h', *audio_data)
            outfile.writeframes(frames_with_message)

    # In ra kết quả
    print(f"Thông điệp đã được giấu vào âm thanh. File đầu ra: {output_audio_path}")


# Sử dụng hàm
embed_message('output_with_noise.wav', 'message.txt', 'audio_with_message.wav')

