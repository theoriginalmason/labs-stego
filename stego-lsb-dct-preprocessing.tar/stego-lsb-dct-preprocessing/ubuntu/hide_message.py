import numpy as np
import scipy.io.wavfile as wav
import scipy.fftpack as fft
import os


# Đọc file âm thanh đầu vào
def read_audio(filename):
    rate, data = wav.read(filename)
    print(f"Rate (tần số lấy mẫu): {rate} Hz")
    print(f"Dữ liệu âm thanh (dạng mảng): {data[:10]} ...")  # In ra 10 mẫu đầu tiên của dữ liệu âm thanh
    return rate, data


# Đọc thông điệp từ file text
def read_message(message_filename):
    with open(message_filename, 'r') as file:
        message = file.read().strip()
    print(f"Thông điệp cần giấu: {message}")
    return message


# Biến đổi DCT lên tín hiệu âm thanh
def apply_dct(audio_data):
    dct_data = fft.dct(audio_data, type=2, axis=-1, norm='ortho')
    print(f"DCT Data (10 mẫu đầu tiên): {dct_data[:10]} ...")
    return dct_data


# Giấu thông điệp vào tín hiệu DCT
# Giấu thông điệp vào tín hiệu DCT
def hide_message_in_dct(dct_data, message):
    # Chuyển đổi thông điệp thành chuỗi nhị phân
    binary_message = ''.join(format(ord(char), '08b') for char in message)
    print(f"Thông điệp nhị phân: {binary_message[:40]} ...")  # In ra 40 bit đầu tiên của thông điệp

    # Giấu thông điệp vào DCT (sử dụng bit thấp nhất của các hệ số DCT)
    message_length = len(binary_message)
    if message_length > len(dct_data):
        raise ValueError("Thông điệp quá dài để giấu trong âm thanh này.")

    # Chuyển đổi DCT thành kiểu số nguyên (int)
    dct_data = np.round(dct_data).astype(int)

    # Gắn thông điệp vào bit thấp nhất của các hệ số DCT
    for i in range(message_length):
        dct_data[i] = (dct_data[i] & ~1) | int(binary_message[i])  # Thay thế bit cuối của hệ số DCT

    print(f"Dữ liệu DCT sau khi giấu thông điệp (10 mẫu đầu tiên): {dct_data[:10]} ...")
    return dct_data


# Lấy lại tín hiệu âm thanh từ DCT
def inverse_dct(dct_data):
    audio_data = fft.idct(dct_data, type=2, axis=-1, norm='ortho')
    return audio_data


# Lưu dữ liệu âm thanh sau khi giấu thông điệp vào file WAV
def save_audio(filename, rate, audio_data):
    audio_data = np.int16(audio_data)  # Chuyển đổi lại về định dạng int16
    wav.write(filename, rate, audio_data)
    print(f"Đã lưu file âm thanh có giấu thông điệp tại: {filename}")


if __name__ == "__main__":
    # Đọc file âm thanh đầu vào
    input_filename = 'input_audio.wav'  # Đổi đường dẫn tới file âm thanh của bạn
    rate, audio_data = read_audio(input_filename)

    # Đọc thông điệp từ file
    message_filename = 'message.txt'  # Đổi đường dẫn tới file chứa thông điệp
    message = read_message(message_filename)

    # Biến đổi tín hiệu âm thanh sang DCT
    dct_data = apply_dct(audio_data)

    # Giấu thông điệp vào tín hiệu DCT
    dct_data_with_message = hide_message_in_dct(dct_data, message)

    # Lấy lại tín hiệu âm thanh từ DCT
    audio_data_with_message = inverse_dct(dct_data_with_message)

    # Lưu âm thanh đã giấu thông điệp
    output_filename = 'audio_with_message.wav'
    save_audio(output_filename, rate, audio_data_with_message)

    print(f"Quá trình giấu thông điệp đã hoàn tất.")

