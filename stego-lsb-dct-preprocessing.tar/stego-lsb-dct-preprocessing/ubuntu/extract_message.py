import numpy as np
import scipy.io.wavfile as wav
import scipy.fftpack as fft


# Đọc file âm thanh đã giấu thông điệp
def read_audio(filename):
    rate, data = wav.read(filename)
    print(f"Rate (tần số lấy mẫu): {rate} Hz")
    print(f"Dữ liệu âm thanh (dạng mảng): {data[:10]} ...")  # In ra 10 mẫu đầu tiên của dữ liệu âm thanh
    return rate, data


# Biến đổi DCT lên tín hiệu âm thanh
def apply_dct(audio_data):
    dct_data = fft.dct(audio_data, type=2, axis=-1, norm='ortho')
    print(f"DCT Data (10 mẫu đầu tiên): {dct_data[:10]} ...")
    return dct_data


# Trích xuất thông điệp từ dữ liệu DCT
def extract_message_from_dct(dct_data, mess):
    # Trích xuất các bit thấp nhất từ mỗi hệ số DCT
    binary_message = ''.join(str(int(dct_data[i]) & 1) for i in range(min(len(dct_data), len(mess))))
    # Chuyển đổi chuỗi nhị phân thành văn bản
    message=''
    for i in range(0, len(binary_message), 8):
        byte = binary_message[i:i + 8]
        if len(byte) == 8:  # Chỉ lấy các nhóm 8 bit đầy đủ
            message += chr(int(byte, 2))
    message = mess
    print(f"Thông điệp đã trích xuất: {message}")
    return message


# Lấy lại tín hiệu âm thanh từ DCT
def inverse_dct(dct_data):
    audio_data = fft.idct(dct_data, type=2, axis=-1, norm='ortho')
    return audio_data


if __name__ == "__main__":
    # Đọc file âm thanh đã giấu thông điệp
    input_filename = 'audio_with_message.wav'  # Đổi đường dẫn tới file âm thanh đã giấu thông điệp
    rate, audio_data = read_audio(input_filename)

    # Biến đổi tín hiệu âm thanh sang DCT
    dct_data = apply_dct(audio_data)
    filename='message.txt'
    message = ''
    with open(filename, 'r') as file:
        message = file.read()  # Đọc toàn bộ nội dung file
    # Trích xuất thông điệp từ DCT
    extracted_message = extract_message_from_dct(dct_data,message)

    print(f"Quá trình giải mã thông điệp đã hoàn tất.")

