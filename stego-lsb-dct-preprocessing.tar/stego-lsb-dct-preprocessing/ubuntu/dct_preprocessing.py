import numpy as np
import scipy.io.wavfile as wav
import scipy.fftpack as fft
import matplotlib.pyplot as plt


# Đọc file âm thanh đầu vào
def read_audio(filename):
    rate, data = wav.read(filename)
    print(f"Rate (tần số lấy mẫu): {rate} Hz")
    print(f"Dữ liệu âm thanh (dạng mảng): {data[:10]} ...")  # In ra 10 mẫu đầu tiên của dữ liệu âm thanh
    return rate, data


# Thực hiện biến đổi DCT lên tín hiệu âm thanh
def apply_dct(audio_data):
    # Áp dụng DCT 1 chiều lên dữ liệu âm thanh
    dct_data = fft.dct(audio_data, type=2, axis=-1, norm='ortho')
    print(f"DCT Data (10 mẫu đầu tiên): {dct_data[:10]} ...")  # In ra 10 mẫu đầu tiên của DCT
    return dct_data


# Lấy lại tín hiệu âm thanh từ DCT (ngược lại với DCT)
def inverse_dct(dct_data):
    audio_data = fft.idct(dct_data, type=2, axis=-1, norm='ortho')
    print(
        f"Tín hiệu âm thanh sau khi biến đổi ngược (10 mẫu đầu tiên): {audio_data[:10]} ...")  # In ra 10 mẫu đầu tiên sau khi lấy ngược DCT
    return audio_data


# Lưu dữ liệu âm thanh sau khi biến đổi ngược lại
def save_audio(filename, rate, audio_data):
    audio_data = np.int16(audio_data)  # Chuyển đổi lại về định dạng int16
    wav.write(filename, rate, audio_data)
    print(f"Đã lưu file âm thanh tại: {filename}")


# Vẽ đồ thị của tín hiệu âm thanh
def plot_audio(data, rate):
    time = np.linspace(0., len(data) / rate, len(data))
    plt.figure(figsize=(10, 4))
    plt.plot(time, data)
    plt.title("Waveform of Audio Signal")
    plt.xlabel("Time [s]")
    plt.ylabel("Amplitude")
    plt.show()


if __name__ == "__main__":
    # Đọc file âm thanh đầu vào
    input_filename = 'input_audio.wav'  # Đổi đường dẫn tới file âm thanh của bạn
    rate, audio_data = read_audio(input_filename)

    # Vẽ tín hiệu âm thanh gốc
    plot_audio(audio_data, rate)

    # Chuyển đổi tín hiệu âm thanh sang DCT
    dct_data = apply_dct(audio_data)

    # Lưu tín hiệu sau khi biến đổi DCT (có thể thực hiện một số thay đổi nếu cần)
    output_filename = 'dct_audio.wav'
    save_audio(output_filename, rate, inverse_dct(dct_data))

    print(f"Đã hoàn thành toàn bộ quá trình xử lý âm thanh.")

