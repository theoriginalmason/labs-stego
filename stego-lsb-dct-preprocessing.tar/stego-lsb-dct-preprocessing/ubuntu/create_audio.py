import numpy as np
import scipy.io.wavfile as wav


# Hàm tạo âm thanh sine wave
def generate_sine_wave(frequency, duration, sample_rate=44100):
    # Tạo mảng thời gian
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)

    # Tạo sóng sin với tần số cho trước
    audio_data = 0.5 * np.sin(2 * np.pi * frequency * t)  # Sóng sin có biên độ 0.5

    # Chuyển đổi kiểu dữ liệu thành int16 (định dạng cần thiết cho file WAV)
    audio_data = np.int16(audio_data * 32767)  # Nhân với 32767 để đưa về dải giá trị int16
    return sample_rate, audio_data


# Hàm lưu âm thanh vào file .wav
def save_audio(filename, rate, audio_data):
    wav.write(filename, rate, audio_data)
    print(f"Đã lưu file âm thanh tại: {filename}")


if __name__ == "__main__":
    # Các tham số âm thanh
    frequency = 440  # Tần số 440Hz (âm thanh của nốt La)
    duration = 5  # Thời gian âm thanh là 5 giây

    # Tạo sóng sin
    rate, audio_data = generate_sine_wave(frequency, duration)

    # Lưu vào file .wav
    output_filename = 'input_audio.wav'
    save_audio(output_filename, rate, audio_data)

