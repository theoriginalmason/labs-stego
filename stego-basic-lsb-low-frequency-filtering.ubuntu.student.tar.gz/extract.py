# Hàm để giải mã thông tin từ âm thanh
import numpy as np

from hiding import message
from preprocessing import read_audio


def decode_message(audio_data, message_length):
    audio_data = audio_data.astype(np.int32)
    binary_message = ''
    for i in range(message_length):
        binary_message += str(audio_data[i] & 1)
    # Chuyển đổi chuỗi nhị phân thành văn bản
    decoded_message = ''.join(chr(int(binary_message[i:i+8], 2)) for i in range(0, len(binary_message), 8))
    return decoded_message

# Đọc âm thanh đã giấu thông tin
audio_data_with_message, _ = read_audio('audio_with_message.wav')

# Giải mã thông tin
decoded_message = decode_message(audio_data_with_message, len(message) * 8)

print("Thông tin giải mã được:")
print(decoded_message)

