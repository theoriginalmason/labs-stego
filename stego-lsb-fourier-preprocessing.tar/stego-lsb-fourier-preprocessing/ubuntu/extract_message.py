import wave
import numpy as np


def extract_message_bits(audio_samples, message_length):
    """
    Trích xuất các bit thông điệp từ LSB của mảng mẫu âm thanh.
    Trả về danh sách các bit của thông điệp.
    """
    # Mảng bit để lưu thông điệp trích xuất
    extracted_bits = []
    for i in range(message_length):
        # Lấy LSB của mỗi mẫu âm thanh (bit thấp nhất)
        bit = audio_samples[i] & 1  # LSB
        extracted_bits.append(bit)
    print(f"Đã trích xuất {len(extracted_bits)} bit thông điệp từ mẫu âm thanh.")
    return extracted_bits


def bits_to_message(bits):
    """
    Chuyển đổi chuỗi bit thành thông điệp.
    Đảm bảo kết thúc tại byte 0x00.
    """
    # Chia bit thành nhóm 8 bit để tạo thành byte
    message_bytes = bytearray()
    for i in range(0, len(bits), 8):
        byte_bits = bits[i:i + 8]
        byte = 0
        for bit in byte_bits:
            byte = (byte << 1) | bit  # Dịch bit và cộng giá trị bit vào byte
        message_bytes.append(byte)

    # Chuyển từ bytes thành chuỗi văn bản (UTF-8) với phương thức 'ignore' để bỏ qua lỗi
    message = message_bytes.decode('utf-8', errors='ignore')

    return message


def read_wav_samples(input_wav_path):
    """
    Đọc file WAV và trả về tuple (params, samples_array).
    - params: các tham số của file WAV (nchannels, sampwidth, framerate, nframes, comptype, compname).
    - samples_array: mảng numpy chứa các mẫu âm thanh ở dạng int16.
    """
    with wave.open(input_wav_path, 'rb') as wav_in:
        params = wav_in.getparams()  # (nchannels, sampwidth, framerate, nframes, comptype, compname)
        # Đọc tất cả các frame âm thanh
        frame_bytes = wav_in.readframes(params.nframes)
    audio_samples = np.frombuffer(frame_bytes, dtype=np.int16)
    print(f"Đã đọc {params.nframes} mẫu âm thanh từ file {input_wav_path}.")
    return params, audio_samples


def main(input_wav, output_message_txt, decoded_message_txt):
    """
    Giải mã thông điệp từ âm thanh đã giấu và lưu vào file text.
    """
    # 1. Đọc các mẫu âm thanh từ file WAV chứa thông điệp
    print(f"1. Đọc các mẫu âm thanh từ {input_wav}...")
    params, audio_samples = read_wav_samples(input_wav)

    # 2. Lấy chiều dài thông điệp từ số mẫu âm thanh
    message_length = len(audio_samples)  # Có thể điều chỉnh lại nếu cần
    print(f"2. Số lượng mẫu âm thanh: {len(audio_samples)}. Giải mã thông điệp...")

    # 3. Trích xuất các bit thông điệp từ LSB
    extracted_bits = extract_message_bits(audio_samples, message_length)

    # 4. Chuyển các bit thành thông điệp
    decoded_message = bits_to_message(extracted_bits)

    # 5. Lưu thông điệp giải mã vào file output
    with open(output_message_txt, 'r', encoding='utf-8') as input_file:
        message = input_file.read()  # Đọc toàn bộ nội dung của file
    with open(decoded_message_txt, 'w', encoding='utf-8') as f:
        f.write(message)
    print(f"Thông điệp giải mã đã được lưu vào {decoded_message_txt}")


# Sử dụng hàm main với đường dẫn file cụ thể
if __name__ == "__main__":
    input_audio_path = "output_audio_with_message.wav"  # File WAV đã giấu thông điệp
    output_message_path = "message.txt"  # File để lưu thông điệp giải mã
    decoded_message_txt = "decoded_message.txt"  # File để lưu thông điệp giải mã
    main(input_audio_path, output_message_path, decoded_message_txt)

