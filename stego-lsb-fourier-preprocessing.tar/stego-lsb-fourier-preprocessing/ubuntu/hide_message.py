import wave
import numpy as np


def read_message_bits(message_path):
    """
    Đọc nội dung file thông điệp và chuyển thành danh sách các bit (bao gồm dấu hiệu kết thúc).
    Sử dụng mã hóa UTF-8 để đảm bảo hỗ trợ mọi ký tự văn bản.
    """
    # Đọc toàn bộ nội dung file văn bản
    with open(message_path, 'r', encoding='utf-8') as f:
        text = f.read()
    print(f"Đọc thông điệp từ {message_path}: {text[:50]}...")  # In 50 ký tự đầu tiên của thông điệp
    # Mã hóa chuỗi văn bản thành bytes (UTF-8)
    message_bytes = text.encode('utf-8')
    # Thêm byte 0x00 làm ký hiệu kết thúc thông điệp
    message_bytes += b'\x00'
    # Chuyển mỗi byte trong thông điệp thành các bit (0 hoặc 1)
    message_bits = []
    for byte in message_bytes:
        # Lấy 8 bit của byte (từ bit 7 đến bit 0)
        for i in range(8):
            bit = (byte >> (7 - i)) & 1  # bit 7 là MSB, bit 0 là LSB
            message_bits.append(bit)
    print(f"Thông điệp đã chuyển thành {len(message_bits)} bit.")
    return message_bits


def read_wav_samples(input_wav_path):
    """
    Đọc file WAV và trả về tuple (params, samples_array).
    - params: các tham số của file WAV (nchannels, sampwidth, framerate, nframes, comptype, compname).
    - samples_array: mảng numpy chứa các mẫu âm thanh ở dạng int16.
    """
    # Mở file WAV ở chế độ đọc nhị phân
    with wave.open(input_wav_path, 'rb') as wav_in:
        params = wav_in.getparams()  # (nchannels, sampwidth, framerate, nframes, comptype, compname)
        # Đọc tất cả các frame âm thanh
        frame_bytes = wav_in.readframes(params.nframes)
    audio_samples = np.frombuffer(frame_bytes, dtype=np.int16)
    print(f"Đọc {params.nframes} mẫu âm thanh từ file {input_wav_path}.")
    return params, audio_samples


def write_wav_samples(output_wav_path, params, audio_samples):
    """
    Ghi mảng mẫu âm thanh (audio_samples) cùng tham số định dạng (params) ra file WAV mới.
    """
    frames_bytes = audio_samples.tobytes()
    with wave.open(output_wav_path, 'wb') as wav_out:
        wav_out.setparams(params)
        wav_out.writeframes(frames_bytes)
    print(f"Ghi dữ liệu vào file {output_wav_path}.")


def embed_message_bits_in_audio(audio_samples, message_bits):
    """
    Nhúng chuỗi bit thông điệp vào LSB của mảng mẫu âm thanh.
    Trả về mảng mẫu âm thanh đã được chỉnh sửa.
    """
    total_samples = audio_samples.shape[0]
    num_bits = len(message_bits)
    print(f"Nhúng {num_bits} bit vào {total_samples} mẫu âm thanh.")
    if num_bits > total_samples:
        raise ValueError("Thông điệp quá dài, không thể nhúng hết vào tín hiệu âm thanh.")
    stego_samples = np.copy(audio_samples)
    bit_array = np.array(message_bits, dtype=np.int16)
    stego_samples[:num_bits] = (stego_samples[:num_bits] & ~1) | bit_array
    print(f"Đã nhúng thông điệp vào các mẫu âm thanh.")
    return stego_samples


def main(input_wav, message_txt, output_wav):
    """Thực hiện quá trình giấu thông điệp vào âm thanh."""
    print(f"1. Đọc thông điệp từ {message_txt}...")
    message_bits = read_message_bits(message_txt)

    print(f"2. Đọc các mẫu âm thanh từ {input_wav}...")
    params, audio_samples = read_wav_samples(input_wav)

    print(f"3. Nhúng thông điệp vào mẫu âm thanh...")
    stego_samples = embed_message_bits_in_audio(audio_samples, message_bits)

    print(f"4. Ghi âm thanh mới với thông điệp đã giấu vào {output_wav}...")
    write_wav_samples(output_wav, params, stego_samples)

    print(f"5. Quá trình hoàn tất: Thông điệp đã được giấu thành công trong file {output_wav}.")


# Sử dụng hàm main với đường dẫn file cụ thể
if __name__ == "__main__":
    # Đường dẫn file âm thanh gốc, file thông điệp và file đầu ra
    input_audio_path = "input_audio.wav"  # File WAV gốc
    message_text_path = "message.txt"  # File chứa thông điệp cần giấu
    output_audio_path = "output_audio_with_message.wav"  # File WAV đầu ra chứa thông điệp
    main(input_audio_path, message_text_path, output_audio_path)

