# create_input_audio.py

import numpy as np
import scipy.io.wavfile as wav


def create_input_audio(filename, sample_rate=44100, duration=5, frequency=440):
    """
    Tạo âm thanh sine wave đơn giản và lưu thành file WAV.
    :param filename: tên file WAV đầu ra.
    :param sample_rate: tần số lấy mẫu (số mẫu/giây), mặc định 44100 Hz (chất lượng CD).
    :param duration: độ dài âm thanh (giây), mặc định 5 giây.
    :param frequency: tần số sóng sine (Hz), mặc định 440 Hz (âm thanh La4).
    """
    # Tạo thời gian mẫu cho âm thanh
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)

    # Tạo sóng sine với tần số và thời gian đã cho
    audio_data = np.sin(2 * np.pi * frequency * t)

    # Chuyển đổi giá trị sóng sine về kiểu dữ liệu int16 (dải tín hiệu âm thanh chuẩn)
    audio_data = np.int16(audio_data * 32767)  # Biến đổi giá trị sóng sine sang giá trị int16

    # Lưu vào file WAV
    wav.write(filename, sample_rate, audio_data)
    print(f"File {filename} đã được tạo thành công!")


# Gọi hàm tạo âm thanh và lưu vào file input_audio.wav
output_filename = "input_audio.wav"
create_input_audio(output_filename)

