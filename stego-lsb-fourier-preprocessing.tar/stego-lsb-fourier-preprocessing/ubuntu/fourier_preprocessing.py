# Xử lý âm thanh bằng biến đổi Fourier kèm in kết quả từng bước
# File đầu vào: input_audio.wav

import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.fft import fft, ifft

def fourier_transform_audio(input_file):
    # Đọc file WAV
    sample_rate, data = wavfile.read(input_file)
    print(f"Tần số mẫu: {sample_rate} Hz")
    print(f"Số lượng mẫu: {len(data)}")

    # Nếu dữ liệu stereo, lấy 1 kênh
    if data.ndim > 1:
        print("Âm thanh có nhiều kênh, lấy kênh đầu tiên.")
        data = data[:, 0]
    else:
        print("Âm thanh đơn kênh.")

    num_samples = len(data)

    # In ra 10 mẫu đầu tiên của tín hiệu
    print("10 mẫu đầu tiên của tín hiệu:")
    print(data[:10])

    # Biến đổi Fourier
    fft_data = fft(data)
    print("\nĐã thực hiện biến đổi Fourier.")

    # Tính biên độ và pha
    amplitude = np.abs(fft_data)
    phase = np.angle(fft_data)

    # Tạo mảng tần số tương ứng
    freqs = np.fft.fftfreq(num_samples, d=1/sample_rate)

    # In ra 10 giá trị đầu tiên của biên độ, pha và tần số
    print("\n10 biên độ đầu tiên từ FFT:")
    print(amplitude[:10])

    print("\n10 pha đầu tiên từ FFT (radian):")
    print(phase[:10])

    print("\n10 tần số đầu tiên (Hz):")
    print(freqs[:10])

    # Biểu diễn phổ biên độ
    plt.figure(figsize=(8, 4))
    plt.plot(freqs[:num_samples // 2], amplitude[:num_samples // 2])
    plt.title("Phổ biên độ âm thanh")
    plt.xlabel("Tần số (Hz)")
    plt.ylabel("Biên độ")
    plt.grid()
    plt.tight_layout()
    plt.show()

    return sample_rate, data, fft_data

if __name__ == "__main__":
    input_file = "input_audio.wav"
    sample_rate, data, fft_data = fourier_transform_audio(input_file)
